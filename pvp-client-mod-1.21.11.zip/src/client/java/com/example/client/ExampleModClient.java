package com.example.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

public class ExampleModClient implements ClientModInitializer {
	// ---------- Toggles (all saved to config/pvpclient.properties) ----------
	public static boolean showFps = false;
	public static boolean showAngles = false;
	public static boolean noTotemPop = false;
	public static boolean noFire = false;
	public static boolean showPops = false;

	// ---------- Enemy pop counter ----------
	public static final Map<String, Integer> POPS = new LinkedHashMap<>();

	public static void addPop(Player player) {
		POPS.merge(player.getName().getString(), 1, Integer::sum);
	}

	private static KeyMapping openMenuKey;

	@Override
	public void onInitializeClient() {
		loadOptions();

		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("modid", "main"));
		openMenuKey = KeyBindingHelper.registerKeyBinding(
				new KeyMapping("key.modid.open_menu", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenuKey.consumeClick()) {
				if (client.screen == null) {
					client.setScreen(new SettingsScreen());
				}
			}
		});

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> POPS.clear());

		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("modid", "hud"), (graphics, deltaTracker) -> renderHud(graphics));
	}

	private static void renderHud(GuiGraphics graphics) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.options.hideGui) {
			return;
		}
		int x = 4;
		int y = 4;
		if (showFps) {
			graphics.drawString(mc.font, mc.getFps() + " FPS", x, y, 0xFFFFFFFF, true);
			y += 11;
		}
		if (showAngles) {
			String text = String.format("Yaw: %.1f  Pitch: %.1f", Mth.wrapDegrees(mc.player.getYRot()), mc.player.getXRot());
			graphics.drawString(mc.font, text, x, y, 0xFFFFFFFF, true);
			y += 11;
		}
		if (showPops) {
			graphics.drawString(mc.font, "Enemy pops:", x, y, 0xFFFFAA00, true);
			y += 11;
			if (POPS.isEmpty()) {
				graphics.drawString(mc.font, "none yet", x, y, 0xFFAAAAAA, true);
			} else {
				int shown = 0;
				for (Map.Entry<String, Integer> entry : POPS.entrySet()) {
					if (shown++ >= 8) {
						break;
					}
					graphics.drawString(mc.font, entry.getKey() + ": " + entry.getValue(), x, y, 0xFFFFFFFF, true);
					y += 11;
				}
			}
		}
	}

	// ---------- Saving / loading ----------
	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("pvpclient.properties");
	}

	public static void loadOptions() {
		Path path = configPath();
		if (!Files.exists(path)) {
			return;
		}
		try (InputStream in = Files.newInputStream(path)) {
			Properties p = new Properties();
			p.load(in);
			showFps = Boolean.parseBoolean(p.getProperty("showFps", "false"));
			showAngles = Boolean.parseBoolean(p.getProperty("showAngles", "false"));
			noTotemPop = Boolean.parseBoolean(p.getProperty("noTotemPop", "false"));
			noFire = Boolean.parseBoolean(p.getProperty("noFire", "false"));
			showPops = Boolean.parseBoolean(p.getProperty("showPops", "false"));
		} catch (Exception ignored) {
		}
	}

	public static void saveOptions() {
		try (OutputStream out = Files.newOutputStream(configPath())) {
			Properties p = new Properties();
			p.setProperty("showFps", String.valueOf(showFps));
			p.setProperty("showAngles", String.valueOf(showAngles));
			p.setProperty("noTotemPop", String.valueOf(noTotemPop));
			p.setProperty("noFire", String.valueOf(noFire));
			p.setProperty("showPops", String.valueOf(showPops));
			p.store(out, "PvP Client options");
		} catch (Exception ignored) {
		}
	}
}
