package com.example.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class SettingsScreen extends Screen {
	public SettingsScreen() {
		super(Component.literal("PvP Client"));
	}

	@Override
	protected void init() {
		int left = this.width / 2 - 155;
		int right = this.width / 2 + 5;
		int top = this.height / 2 - 52;

		addToggle(left, top, "FPS Counter", () -> ExampleModClient.showFps, v -> ExampleModClient.showFps = v);
		addToggle(right, top, "Angle Shower", () -> ExampleModClient.showAngles, v -> ExampleModClient.showAngles = v);
		addToggle(left, top + 24, "No Totem Pop Effect", () -> ExampleModClient.noTotemPop, v -> ExampleModClient.noTotemPop = v);
		addToggle(right, top + 24, "No Fire Overlay", () -> ExampleModClient.noFire, v -> ExampleModClient.noFire = v);
		addToggle(left, top + 48, "Enemy Pop Counter", () -> ExampleModClient.showPops, v -> ExampleModClient.showPops = v);

		this.addRenderableWidget(Button.builder(Component.literal("Reset Pop Counter"), button -> ExampleModClient.POPS.clear())
				.bounds(right, top + 48, 150, 20).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), button -> this.onClose())
				.bounds(this.width / 2 - 75, top + 76, 150, 20).build());
	}

	private void addToggle(int x, int y, String name, BooleanSupplier getter, Consumer<Boolean> setter) {
		this.addRenderableWidget(Button.builder(label(name, getter.getAsBoolean()), button -> {
			boolean now = !getter.getAsBoolean();
			setter.accept(now);
			button.setMessage(label(name, now));
		}).bounds(x, y, 150, 20).build());
	}

	private static Component label(String name, boolean on) {
		return Component.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		super.render(graphics, mouseX, mouseY, partialTick);
		graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 72, 0xFFFFFFFF);
	}

	@Override
	public void removed() {
		ExampleModClient.saveOptions();
	}
}
