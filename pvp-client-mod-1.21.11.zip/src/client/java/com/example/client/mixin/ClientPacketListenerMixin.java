package com.example.client.mixin;

import com.example.client.ExampleModClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class ClientPacketListenerMixin {
	@Inject(method = "handleEntityEvent", at = @At("HEAD"), cancellable = true)
	private void modid$onEntityEvent(ClientboundEntityEventPacket packet, CallbackInfo ci) {
		Minecraft mc = Minecraft.getInstance();
		// The packet is first received on the network thread and then re-run on the game thread.
		// Only act on the game thread so each pop is counted once.
		if (!mc.isSameThread() || mc.level == null) {
			return;
		}
		if (packet.getEventId() != 35) { // 35 = totem of undying popped
			return;
		}
		Entity entity = packet.getEntity(mc.level);
		if (entity instanceof Player player && player != mc.player) {
			ExampleModClient.addPop(player);
		}
		if (ExampleModClient.noTotemPop) {
			ci.cancel();
		}
	}
}
